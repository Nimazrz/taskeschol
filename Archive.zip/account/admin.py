from django.contrib import admin
from .models import *
# class CustomUserAdmin():
#     model = Teacher
#     list_display = ('username', 'first_name','is_teacher', 'last_name', 'is_staff', 'is_active', 'is_superuser')
#     list_filter = ('is_staff', 'is_active', 'is_superuser', 'is_teacher')
#     fieldsets = (
#         (None, {'fields': ('username', 'password')}),
#         ('Personal Info', {'fields': ('first_name', 'last_name', 'meli_code', 'school', 'bio', 'is_teacher')}),
#         ('Permissions', {'fields': ('is_staff', 'is_active', 'is_superuser', 'groups', 'user_permissions')}),
#         ('Important dates', {'fields': ('last_login', 'date_joined')}),
#     )
#     add_fieldsets = (
#         (None, {
#             'classes': ('wide',),
#             'fields': ('username', 'password1', 'password2', 'first_name', 'last_name', 'meli_code', 'is_staff', 'is_active')}
#         ),
#     )
#     search_fields = ('username', 'first_name', 'last_name', 'meli_code')
#     ordering = ('username',)
#     filter_horizontal = ('groups', 'user_permissions')

# admin.site.register(Teacher, CustomUserAdmin)


# admin.py



@admin.register(Teacher)
class TeacherAdmin(admin.ModelAdmin):
    list_display = ('username', 'first_name', 'last_name',)
    search_fields = ('username', 'first_name', 'last_name')
    list_filter = ('is_active', 'is_teacher', 'school')
    ordering = ('-created_at',)

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('username', 'first_name', 'last_name',)
    search_fields = ('username', 'first_name', 'last_name')
    list_filter = ('is_active', )
    ordering = ('-created_at',)