from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

app_name = 'school'

urlpatterns = [
    path('', views.index, name='index'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.loged_out, name='logout'),
    path('register/', views.register, name='register'),

]