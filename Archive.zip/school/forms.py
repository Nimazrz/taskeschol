from django import forms
from django.contrib.auth.models import User

from account.models import *


class TeacherRegisterForm(forms.ModelForm):
    password = forms.CharField(max_length=250, required=True, widget=forms.PasswordInput)
    password2 = forms.CharField(max_length=250, required=True, widget=forms.PasswordInput)

    class Meta:
        model = Teacher
        fields = ('username', 'first_name', 'last_name', 'meli_code', 'school', 'bio', 'is_teacher')

    def clean_password2(self):
        password = self.cleaned_data.get('password')
        password2 = self.cleaned_data.get('password2')
        if password != password2:
            raise forms.ValidationError("Passwords must match")
        return password

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if phone != "":
            if phone.isdigit():
                if Teacher.objects.filter(phone=phone).exists():
                    raise forms.ValidationError("this phone number is already taken")
                return phone
            else:
                raise forms.ValidationError("Please enter a valid phone number")

    def clean_meli_code(self):
        meli_code = self.cleaned_data.get('meli_code')
        if meli_code != "":
            if meli_code.isdigit():
                if Teacher.objects.filter(meli_code=meli_code).exists():
                    raise forms.ValidationError("this phone number is already taken")
                return meli_code
            else:
                raise forms.ValidationError("Please enter a valid phone number")


class StudentRegisterForm(forms.ModelForm):
    password = forms.CharField(max_length=250, required=True, widget=forms.PasswordInput)
    password2 = forms.CharField(max_length=250, required=True, widget=forms.PasswordInput)

    class Meta:
        model = Student
        fields = ('username', 'first_name', 'last_name', 'meli_code', 'school', 'bio', 'is_teacher')

    def clean_password2(self):
        password = self.cleaned_data.get('password')
        password2 = self.cleaned_data.get('password2')
        if password != password2:
            raise forms.ValidationError("Passwords must match")
        return password

    def clean_phone(self):
        phone = self.cleaned_data.get('phone')
        if phone != "":
            if phone.isdigit():
                if Student.objects.filter(phone=phone).exists():
                    raise forms.ValidationError("this phone number is already taken")
                return phone
            else:
                raise forms.ValidationError("Please enter a valid phone number")

    def clean_meli_code(self):
        meli_code = self.cleaned_data.get('meli_code')
        if meli_code != "":
            if meli_code.isdigit():
                if Student.objects.filter(meli_code=meli_code).exists():
                    raise forms.ValidationError("this phone number is already taken")
                return meli_code
            else:
                raise forms.ValidationError("Please enter a valid phone number")

class LoginForm(forms.Form):
    username = forms.CharField(max_length=250, required=True, widget=forms.TextInput)
    password = forms.CharField(max_length=250, required=True, widget=forms.PasswordInput)
